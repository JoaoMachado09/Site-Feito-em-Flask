atracoes = [
    {
        "id": 1,
        "nome": "É assim que acaba",
        "imagem": "LivroCapa1.jpg",
        "descricao": "Em É assim que acaba , Colleen Hoover nos apresenta Lily, uma jovem que se mudou de uma cidadezinha do Maine para Boston, se formou em marketing e abriu a própria floricultura. E é em um dos terraços de Boston que ela conhece Ryle, um neurocirurgião confiante, teimoso e talvez até um pouco arrogante, com uma grande aversão a relacionamentos, mas que se sente muito atraído por ela. ",
        "autor": "Colleen Hoover ",
        "comentarios": [
            {"autor": "João", "opiniao": "Otimo livro! Muito Profundo"},
            {"autor": "Maria", "opiniao": "Livro autentico!"}
        ]
    },
    {
        "id": 2,
        "nome": "O poder do silêncio",
        "imagem": "LivroCapa2.jpg",
        "descricao": "Um dos maiores fenômenos da literatura espiritual dos últimos tempos, Eckhart Tolle, autor de O Poder do Agora, nos mostra a importância de silenciar os pensamentos e reencontrar nossa sabedoria interior para viver mais intensamente o momento atual.!",
        "autor": "Eckhart Tolle",
        "comentarios": [
            {"autor": "Carlos", "opiniao": "Me ajudou muito a crescer como pessoa!"},
            {"autor": "Ana", "opiniao": "Sou alguém melhor agora!"}
        ]
    },
    {
        "id": 3,
        "nome": "Nunca é hora de parar",
        "imagem": "LivroCapa3.jpg",
        "descricao": "“A única coisa que sei é: eu sou David Goggins. Existo, logo termino o que começo. Tenho orgulho do meu esforço. E, enquanto eu estiver no planeta Terra, não vou fazer nada pela metade.” – David Goggins",
        "autor": "David Gonggins",
        "comentarios": [
            {"autor": "Carlos", "opiniao": "David sou seu fã!"},
            {"autor": "Ana", "opiniao": "Melhor livro para começar a se dedicar mais!"}
        ]
    }

]